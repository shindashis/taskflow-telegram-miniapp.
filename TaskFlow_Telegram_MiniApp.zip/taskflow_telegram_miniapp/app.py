import hashlib
import hmac
import json
import os
import sqlite3
import time
from urllib.parse import parse_qsl

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
DB_PATH = os.getenv("DATABASE_PATH", "taskflow.sqlite3")

app = FastAPI(title="TaskFlow Mini App")
app.mount("/static", StaticFiles(directory="static"), name="static")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'Личное',
                priority TEXT NOT NULL DEFAULT 'Обычный',
                done INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            )
        """)

init_db()

def validate_init_data(init_data: str) -> int:
    if not BOT_TOKEN:
        raise HTTPException(503, "Bot token is not configured")
    if not init_data:
        raise HTTPException(401, "Open this app from Telegram")
    data = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = data.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Invalid Telegram authorization data")
    auth_date = int(data.get("auth_date", "0"))
    if time.time() - auth_date > 86400:
        raise HTTPException(401, "Telegram authorization data expired")
    check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Telegram authorization check failed")
    user = json.loads(data.get("user", "{}"))
    if not user.get("id"):
        raise HTTPException(401, "Telegram user is missing")
    return int(user["id"])

def current_user(authorization: str | None) -> int:
    if not authorization or not authorization.startswith("tma "):
        raise HTTPException(401, "Missing Telegram init data")
    return validate_init_data(authorization[4:])

class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    category: str = Field(default="Личное", max_length=32)
    priority: str = Field(default="Обычный", max_length=16)

class TaskUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=120)
    category: str | None = Field(default=None, max_length=32)
    priority: str | None = Field(default=None, max_length=16)
    done: bool | None = None

@app.get("/")
def index():
    return FileResponse("static/index.html")

@app.get("/api/tasks")
def list_tasks(authorization: str | None = Header(default=None)):
    uid = current_user(authorization)
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM tasks WHERE user_id=? ORDER BY done ASC, id DESC", (uid,)
        ).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/tasks")
def create_task(task: TaskCreate, authorization: str | None = Header(default=None)):
    uid = current_user(authorization)
    title = task.title.strip()
    if not title:
        raise HTTPException(400, "Task title cannot be empty")
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO tasks(user_id,title,category,priority,created_at) VALUES(?,?,?,?,?)",
            (uid, title, task.category, task.priority, int(time.time()))
        )
        row = conn.execute("SELECT * FROM tasks WHERE id=?", (cur.lastrowid,)).fetchone()
    return dict(row)

@app.patch("/api/tasks/{task_id}")
def update_task(task_id: int, task: TaskUpdate, authorization: str | None = Header(default=None)):
    uid = current_user(authorization)
    updates = task.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No changes supplied")
    if "done" in updates:
        updates["done"] = int(updates["done"])
    if "title" in updates:
        updates["title"] = updates["title"].strip()
        if not updates["title"]:
            raise HTTPException(400, "Task title cannot be empty")
    allowed = {"title", "category", "priority", "done"}
    if any(k not in allowed for k in updates):
        raise HTTPException(400, "Invalid field")
    sql = ", ".join(f"{k}=?" for k in updates)
    with db() as conn:
        cur = conn.execute(
            f"UPDATE tasks SET {sql} WHERE id=? AND user_id=?",
            (*updates.values(), task_id, uid)
        )
        if cur.rowcount == 0:
            raise HTTPException(404, "Task not found")
        row = conn.execute("SELECT * FROM tasks WHERE id=? AND user_id=?", (task_id, uid)).fetchone()
    return dict(row)

@app.delete("/api/tasks/{task_id}")
def delete_task(task_id: int, authorization: str | None = Header(default=None)):
    uid = current_user(authorization)
    with db() as conn:
        cur = conn.execute("DELETE FROM tasks WHERE id=? AND user_id=?", (task_id, uid))
    if cur.rowcount == 0:
        raise HTTPException(404, "Task not found")
    return {"ok": True}
