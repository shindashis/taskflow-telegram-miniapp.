# TaskFlow — Telegram Mini App

Готовый стартовый проект: Telegram-бот на aiogram 3, Mini App на HTML/CSS/JS и API на FastAPI с SQLite.

## Что реализовано
- Запуск Mini App кнопкой в Telegram через `/start`.
- Персональные задачи, привязанные к Telegram user ID.
- Создание, редактирование, удаление и отметка выполнения.
- Категории, приоритеты, фильтры и индикатор прогресса.
- Проверка подписи `Telegram.WebApp.initData` на сервере (не доверяем user ID из браузера).

## Что потребуется
1. Telegram и бот, созданный через официальный `@BotFather`.
2. Токен бота. Не отправляй его в чаты и не публикуй в репозитории.
3. Публичный HTTPS-адрес для Mini App. Telegram требует HTTPS для обычного Web App.
4. Python 3.10+.

## Установка
```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env            # Windows: скопируй файл вручную
```
Заполни `.env`:
- `BOT_TOKEN` — токен от BotFather.
- `WEBAPP_URL` — публичный HTTPS URL, по которому открывается это приложение.

## Запуск
В первом терминале запусти веб-сервер:
```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```
Во втором:
```bash
python bot.py
```
Открой бота в Telegram и отправь `/start`.

Для теста с локального компьютера можно временно открыть порт 8000 через HTTPS-туннель (например, Cloudflare Tunnel или ngrok), затем указать выданный HTTPS URL в `WEBAPP_URL` и перезапустить бота. Не публикуй `.env`.

## Важные ограничения текущей версии
- Это рабочий MVP, а не размещённый в интернете сервис: сам архив не создаёт Telegram-бота и не арендует сервер.
- SQLite подходит для тестирования на одном экземпляре. Для публичного масштабирования лучше PostgreSQL.
- Для production добавь HTTPS-хостинг, ограничение частоты запросов, резервное копирование БД и мониторинг.
- Не отключай проверку `initData` на сервере.

## Структура
```
taskflow_telegram_miniapp/
  bot.py
  app.py
  requirements.txt
  .env.example
  static/
    index.html
    style.css
    app.js
```
